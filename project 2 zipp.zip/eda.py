"""Project 2 - EDA of e-commerce orders (Jan 2023 - Jun 2025)."""
import pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

df = pd.read_excel("data.xlsx")
df["CouponCode"] = df["CouponCode"].fillna("No coupon")
df["Month"] = df.Date.dt.to_period("M")
plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150, "font.size": 10})
C = "#2F6DB5"; G = "#C0392B"

# ---- 1. Data quality
print("rows", len(df), "dups", df.duplicated().sum(), "nulls", df.isna().sum().sum())
print("TotalPrice != Qty*UnitPrice:", (abs(df.Quantity*df.UnitPrice-df.TotalPrice) > .01).sum())

# ---- 2. Summary stats
for c in ["Quantity","UnitPrice","TotalPrice","ItemsInCart"]:
    s = df[c]; print(c, s.describe().round(2).to_dict(), "skew", round(s.skew(),2))

# ---- 3. Outliers (IQR + Z)
q1,q3 = df.TotalPrice.quantile([.25,.75]); iqr=q3-q1
hi = q3+1.5*iqr; out = df[df.TotalPrice>hi]
z = np.abs(stats.zscore(df.TotalPrice))
print("IQR upper fence", round(hi,2), "outliers", len(out), "share of rev", round(out.TotalPrice.sum()/df.TotalPrice.sum()*100,1))
print("Z>3:", (z>3).sum()); print(out.Product.value_counts().to_dict()); print(out.OrderStatus.value_counts().to_dict())

# ---- 4. Status / revenue realisation
st = df.groupby("OrderStatus").agg(orders=("OrderID","count"), revenue=("TotalPrice","sum"), avg=("TotalPrice","mean"))
print(st.round(1)); tot=df.TotalPrice.sum()
lost = df[df.OrderStatus.isin(["Cancelled","Returned"])].TotalPrice.sum()
print("total", round(tot), "cancel+return", round(lost), round(lost/tot*100,1),"%")

# ---- 5. Product, channel, payment, coupon
prod = df.groupby("Product").agg(orders=("OrderID","count"), units=("Quantity","sum"), revenue=("TotalPrice","sum"), avg_price=("UnitPrice","mean"), median_order=("TotalPrice","median")).sort_values("revenue",ascending=False)
print(prod.round(1))
for c in ["ReferralSource","PaymentMethod","CouponCode"]:
    g = df.groupby(c).agg(orders=("OrderID","count"), revenue=("TotalPrice","sum"), aov=("TotalPrice","mean"), lost=("OrderStatus", lambda s: s.isin(["Cancelled","Returned"]).mean()*100))
    print(g.round(1))
    print("chi2 status vs", c, "p=", round(stats.chi2_contingency(pd.crosstab(df[c], df.OrderStatus))[1],3))
print("ANOVA price by product p=", round(stats.f_oneway(*[g.UnitPrice for _,g in df.groupby("Product")])[1],3))
print("Kruskal TotalPrice by coupon p=", round(stats.kruskal(*[g.TotalPrice for _,g in df.groupby("CouponCode")])[1],3))

# ---- 6. Time
m = df.groupby(df.Date.dt.to_period("M")).TotalPrice.sum()
y = df.groupby(df.Date.dt.year).agg(rev=("TotalPrice","sum"), n=("OrderID","count"))
print(y); 
h1 = lambda yr: df[(df.Date.dt.year==yr)&(df.Date.dt.month<=6)].TotalPrice.sum()
print("H1 23/24/25", round(h1(2023)), round(h1(2024)), round(h1(2025)))
print("monthly best/worst", m.idxmax(), round(m.max()), m.idxmin(), round(m.min()))
dow = df.groupby(df.Date.dt.day_name()).TotalPrice.agg(["count","sum"]); print(dow)
mm = df.groupby(df.Date.dt.month).TotalPrice.sum(); print(mm.round(0).to_dict())

# ---- 7. Correlation
cor = df[["Quantity","UnitPrice","TotalPrice","ItemsInCart"]].corr().round(2); print(cor)
print("qty vs unitprice r,p", stats.pearsonr(df.Quantity, df.UnitPrice))
print("cart vs total", stats.pearsonr(df.ItemsInCart, df.TotalPrice))
print("repeat customers", (df.CustomerID.value_counts()>1).sum(), "of", df.CustomerID.nunique())
print("cart items < qty:", (df.ItemsInCart<df.Quantity).sum())

# ---- Charts
fig,ax=plt.subplots(1,2,figsize=(10,3.6))
ax[0].hist(df.TotalPrice,bins=40,color=C); ax[0].axvline(df.TotalPrice.median(),color=G,ls="--",label=f"Median ${df.TotalPrice.median():,.0f}"); ax[0].axvline(df.TotalPrice.mean(),color="k",ls=":",label=f"Mean ${df.TotalPrice.mean():,.0f}"); ax[0].set_title("Order values are right-skewed"); ax[0].set_xlabel("Order total ($)"); ax[0].legend(frameon=False)
ax[1].boxplot(df.TotalPrice,vert=False,widths=.5,flierprops=dict(markerfacecolor=G,markeredgecolor=G,markersize=3)); ax[1].set_title("IQR outliers above $%s"%f"{hi:,.0f}"); ax[1].set_xlabel("Order total ($)"); ax[1].set_yticks([])
plt.tight_layout(); plt.savefig("charts/01_distribution.png"); plt.close()

fig,ax=plt.subplots(figsize=(10,3.6)); m.index=m.index.to_timestamp()
ax.plot(m.index,m.values,color=C,marker="o",ms=3,label="Monthly revenue"); ax.plot(m.index,m.rolling(3).mean(),color=G,lw=2,label="3-month average"); ax.set_title("Monthly revenue is volatile with no clear seasonality"); ax.set_ylabel("Revenue ($)"); ax.legend(frameon=False)
plt.tight_layout(); plt.savefig("charts/02_monthly.png"); plt.close()

fig,ax=plt.subplots(1,2,figsize=(10,3.6))
p=prod.revenue.sort_values(); ax[0].barh(p.index,p.values/1e3,color=C); ax[0].set_title("Revenue by product ($K)")
for i,v in enumerate(p.values/1e3): ax[0].text(v,i,f" {v:,.0f}",va="center")
s=st.orders.reindex(["Delivered","Shipped","Pending","Returned","Cancelled"]); ax[1].bar(s.index,s.values,color=[C,C,"#999",G,G]); ax[1].set_title("Orders by status (~40% cancelled/returned)"); ax[1].tick_params(axis="x",rotation=25)
plt.tight_layout(); plt.savefig("charts/03_product_status.png"); plt.close()

fig,ax=plt.subplots(figsize=(4.8,3.8)); import seaborn as sns
sns.heatmap(cor,annot=True,cmap="RdBu_r",vmin=-1,vmax=1,ax=ax,cbar=False); ax.set_title("Pearson correlations"); plt.tight_layout(); plt.savefig("charts/04_corr.png"); plt.close()

fig,ax=plt.subplots(1,2,figsize=(10,3.6))
r=df.groupby("ReferralSource").TotalPrice.sum().sort_values(); ax[0].barh(r.index,r.values/1e3,color=C); ax[0].set_title("Revenue by referral source ($K)")
ax[1].bar(["Quarterly"]*0,[]) ; q=df.groupby(df.Date.dt.to_period("Q")).TotalPrice.sum(); ax[1].bar(q.index.astype(str),q.values/1e3,color=C); ax[1].tick_params(axis="x",rotation=45); ax[1].set_title("Quarterly revenue ($K)")
plt.tight_layout(); plt.savefig("charts/05_channel_quarter.png"); plt.close()
