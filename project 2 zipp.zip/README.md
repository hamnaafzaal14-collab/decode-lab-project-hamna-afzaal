# E-Commerce Orders - Exploratory Data Analysis (Project 2)

**Question:** where does revenue come from, is it growing, and where does it leak?

**Headline findings**
- Jan-Jun revenue fell ~10% per year (2023 -> 2025) because of fewer orders, not smaller baskets.
- 41% of order value is in Cancelled/Returned orders.
- Revenue is evenly spread across 7 products; Instagram has the lowest cancel/return rate.
- Coupons are not applied to TotalPrice and show no effect on order value.

**Files**
- `EDA_Report.docx` - full write-up (read this first)
- `eda.py` - reproducible analysis; run `python eda.py` (needs pandas, scipy, matplotlib, seaborn, openpyxl)
- `data.xlsx` - source data (1,200 orders)
- `eda_output.txt` - printed statistics
- `charts/` - figures used in the report

**Caveat:** the data appears synthetic (near-uniform distributions), so treat conclusions as an analytical exercise.
