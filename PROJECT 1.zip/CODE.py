# DATA ANALYTICS - PROJECT 1
# Data Cleaning and Preparation

import pandas as pd
from pathlib import Path

# File locations
folder = Path(__file__).resolve().parent
input_file = folder / "Dataset for Data Analytics.xlsx"

# Read Excel dataset
df = pd.read_excel(input_file, sheet_name=0)

print("Original Dataset Shape:", df.shape)

# Store original quality information
original_rows = len(df)
original_columns = len(df.columns)

missing_before = int(df.isnull().sum().sum())
missing_details = df.isnull().sum()

duplicate_rows_before = int(df.duplicated().sum())
duplicate_ids_before = int(df["OrderID"].duplicated().sum())

# 1. Handle Missing Values
df["CouponCode"] = df["CouponCode"].fillna("Not Provided")

# 2. Remove Duplicate Rows
df = df.drop_duplicates()

# 3. Check and Remove Duplicate Order IDs
df = df.drop_duplicates(subset=["OrderID"], keep="first")

# 4. Correct Date Format
df["Date"] = pd.to_datetime(df["Date"], errors="coerce")

invalid_dates = int(df["Date"].isna().sum())

# 5. Clean Text Columns
text_columns = df.select_dtypes(include="object").columns

for col in text_columns:
    df[col] = df[col].apply(
        lambda x: x.strip() if isinstance(x, str) else x
    )

# 6. Correct Numeric Formats
numeric_columns = ["Quantity", "UnitPrice", "TotalPrice"]

for col in numeric_columns:
    df[col] = pd.to_numeric(df[col], errors="coerce")

# 7. Check Quantity x UnitPrice
valid = df[numeric_columns].notna().all(axis=1)

mismatch = (
    (df["Quantity"] * df["UnitPrice"] - df["TotalPrice"]).abs() > 0.02
) & valid

mismatch_count = int(mismatch.sum())

# 8. Final Quality Checks
missing_after = int(df.isnull().sum().sum())
duplicate_rows_after = int(df.duplicated().sum())
duplicate_ids_after = int(df["OrderID"].duplicated().sum())

# 9. Prepare Quality Report
quality_report = pd.DataFrame({
    "Quality Check": [
        "Total records before cleaning",
        "Total records after cleaning",
        "Original columns",
        "Missing values before cleaning",
        "Missing values after cleaning",
        "Duplicate rows before cleaning",
        "Duplicate rows after cleaning",
        "Duplicate OrderIDs before cleaning",
        "Duplicate OrderIDs after cleaning",
        "Invalid dates after cleaning",
        "Quantity x UnitPrice mismatches"
    ],
    "Result": [
        original_rows,
        len(df),
        original_columns,
        missing_before,
        missing_after,
        duplicate_rows_before,
        duplicate_rows_after,
        duplicate_ids_before,
        duplicate_ids_after,
        invalid_dates,
        mismatch_count
    ]
})

# 10. Save Cleaned Dataset as CSV
df.to_csv(
    folder / "Cleaned_Dataset.csv",
    index=False
)

# 11. Save Excel Workbook with Quality Report
with pd.ExcelWriter(
    folder / "Data_Analytics_Project1_Cleaned.xlsx",
    engine="openpyxl"
) as writer:

    df.to_excel(
        writer,
        sheet_name="Cleaned_Data",
        index=False
    )

    quality_report.to_excel(
        writer,
        sheet_name="Quality_Report",
        index=False
    )

# 12. Display Results
print("\nDATA CLEANING COMPLETED!")

print("\nMissing Values Before Cleaning:")
print(missing_details)

print("\nQuality Report:")
print(quality_report.to_string(index=False))

print("\nCleaned Dataset Shape:", df.shape)

print("\nFiles Saved Successfully!")
print("1. Cleaned_Dataset.csv")
print("2. Data_Analytics_Project1_Cleaned.xlsx")